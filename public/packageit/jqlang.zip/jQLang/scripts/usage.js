/**
 * @author ossreleasefeed
 */
$(document).ready(function() {
	$('a').jqlang();	
});

